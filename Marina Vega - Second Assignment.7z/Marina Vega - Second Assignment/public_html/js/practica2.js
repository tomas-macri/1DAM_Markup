const CODIGO=25;

function misterio1(htmlDocument,id){
    if(htmlDocument.getElementById(id)){
        return htmlDocument.getElementById(id).innerHTML;
    }
    else{
        return "No existe ese id";
    }
}

function misterio2(htmlDocument, myClassName){
    let elements = htmlDocument.getElementsByClassName(myClassName);
    if(elements.length === 0) {
        result = "No existen con esa clase";
    }
    else {
        result = elements[0].style.color;
    }
    return result;
}
function misterio3(htmlDocument, tagName){
    let elements = htmlDocument.getElementsByTagName(tagName);
    let result;
    
    if (elements.length === 0) {
        result = "No existen con esa etiqueta";
    }
    else {
        for(i=0; i < elements.length; i++){
            elements[i].id = "el" + tagName + (i+1);
        }
        result = elements;
    }
    return result;
}
function misterio4(htmlDocument, myTag, myClassName){
    if(htmlDocument.querySelector(myTag + "." + myClassName)) {
        return true;
    }
    else {
        return false;
    }
}
function misterio5(htmlDocument, myClassName){
    let result = htmlDocument.getElementsByClassName(myClassName).length;
    return result;
}
function misterio6(htmlDocument, newId){
    let element = htmlDocument.createElement("h1");
    element.id = newId;
    htmlDocument.body.appendChild(element);
    return true;
}
function misterio7(htmlDocument, newId, text, parentId){
    let element = htmlDocument.createElement("h2");
    element.id = newId;
    let node = htmlDocument.createTextNode(text);
    element.appendChild(node);
    let parentElement = htmlDocument.getElementById(parentId);
    if(parentElement !== null){
        parentElement.appendChild(element);
    }
    else {
        htmlDocument.body.appendChild(element);
    }
    return true;
}
function misterio8(htmlDocument){
    let unList = htmlDocument.createElement("ul");
    for (i=0; i<3; i++){
        let listItem = htmlDocument.createElement("li");
        let node = htmlDocument.createTextNode("HOLA");
        listItem.className = "linea";
        listItem.appendChild(node);
        unList.appendChild(listItem);
    }      
    htmlDocument.body.appendChild(unList);
    return true;
}
function misterio9(){
    return true;
}
function misterio10(htmlDocument, newTag, newId, newColor, newBgColor, text){
    let element = htmlDocument.createElement(newTag);
    element.id = newId;
    element.style.color = newColor;
    element.style.backgroundColor = newBgColor;
    let node = htmlDocument.createTextNode(text);
    element.appendChild(node);
    htmlDocument.body.appendChild(element);
    
    return true;
}
function misterio11(htmlDocument, myId){
    if (htmlDocument.getElementById(myId) === null) {
        result = "No existe ese id";
    }
    else {
        result = htmlDocument.getElementById(myId).classList = "clase";
    }
    return result;
}
function misterio12(htmlDocument, newId){
    let number = htmlDocument.getElementById(newId);
    if(number === null) {
        number = 0;
    }
    else {
        number = number.childElementCount;
        number = number + 1;
    }
    return number;
}
function misterio13(htmlDocument, myTitle){
    htmlDocument.title = myTitle;
    return true;
}
function misterio14(htmlDocument, myClassName){
    let elements = htmlDocument.getElementsByClassName(myClassName);
    let length = elements.length;
    for(i=0; i<length; i++) {
        let parent = elements[0].parentElement;
        let child = elements[0];
        parent.removeChild(child);
    }
    let resultado = "Eliminados:" + length;
    return resultado;
}


 module.exports = {
    misterio1,
    misterio2,
    misterio3,
    misterio4,
    misterio5,
    misterio6,
    misterio7,
    misterio8,
    misterio9,
    misterio10,
    misterio11,
    misterio12,
    misterio13,
    misterio14,
    CODIGO
}

